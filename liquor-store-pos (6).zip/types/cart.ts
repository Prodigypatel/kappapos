export type CartItem = {
  id: string
  barcode: string
  name: string
  price: number
  qty_on_hand_items: number
  qty_on_hand_cases: number
  units_per_case: number
  quantity: number
  isCase: boolean
}

